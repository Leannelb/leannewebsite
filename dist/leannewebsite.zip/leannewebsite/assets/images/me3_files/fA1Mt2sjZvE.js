if (self.CavalryLogger) { CavalryLogger.start_js(["cVTAQ"]); }

__d("XPagesMercuryIndicatorController",["XController"],(function(a,b,c,d,e,f){e.exports=b("XController").create("/pages/messaging/mercury/indicator/",{})}),null);