if (self.CavalryLogger) { CavalryLogger.start_js(["kIHQG"]); }

__d("XChatEmojiSettingsController",["XController"],(function(a,b,c,d,e,f){e.exports=b("XController").create("/chat/emoji_settings/",{__asyncDialog:{type:"Int"}})}),null);