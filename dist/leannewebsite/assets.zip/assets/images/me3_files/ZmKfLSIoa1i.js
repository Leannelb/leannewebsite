if (self.CavalryLogger) { CavalryLogger.start_js(["V4zJx"]); }

__d("ChatSidebarGroupCreateButtonReactComponent",["ChatSidebarGroupCreateButtonReact.bs"],(function(a,b,c,d,e,f){"use strict";a=b("ChatSidebarGroupCreateButtonReact.bs").jsComponent;e.exports=a}),null);